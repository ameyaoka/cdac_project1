
# project (snacks in seconds)

## libraries used

1. database (mysql)
2. Mysql-connector-python
3. streamlit 




- files 

	- userdata.py 
	  	- database related 
		- connector to connect to mysq database
		- functions for executing sql queries 
			- login 
			- signup
			- get_details
			- place_order
			- update_password 

	- main.py

	- admin_login.py


